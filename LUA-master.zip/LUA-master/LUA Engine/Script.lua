--lua
team = {0, 0, 0, 0}
weapon = {0, 0, 0, 0, 0, 0}
teamName = {"Dwight Power", "Jean O. Cider", "F. Nick Glensing", "K. Lanceman"}
weaponName = {"Dual Pistols", "Assault Rifle", "Hunting Rifle with Scope", "Grenade Belt", "RPG", "Remote Controlled Claymores"}

function story(aName)
    if(aName == "start") then
	    CLS()
	    playMusic("agentOrange.wav")
		setBackground('burningForrest.JPG')
        createTextfield("You're being drafted and sent on a mission to Scion.\nYour government demands so.")
		createButton("exit", " ")
		createButton("exit", "Quit")
        createButton("chooseTeam", "Let's roll")
    end
	if(aName == "chooseTeam") then
	    CLS()
		team = {0, 0, 0, 0}
		setBackground('darkJungle.JPG')
        createTextfield("Major J. 'Angelface' Mengele decides for your division\nto be splitted into 4 groups of 3, to decrease the chance of the enemy spotting\nall of you. Who would you be trusting your life to?")
		createButton("exit", " ")
		createButton("team03", "Sergeant K. Lanceman")
		createButton("team02", "Sergeant F. Nick Glensing")
		createButton("team01", "Sergeant Jean O. Cider")
		createButton("team00", "Sergeant Dwight Power")
    end
	if(aName == "team00") then
		team[0] = 1
		aName = "weaponBegin"
	end
	if(aName == "team01") then
		team[1] = 1
		aName = "weaponBegin"
	end
	if(aName == "team02") then
		team[2] = 1
		aName = "weaponBegin"
	end
	if(aName == "team03") then
		team[3] = 1
		aName = "weaponBegin"
	end
	if(aName == "weaponBegin") then
	    CLS()
		weapon = {0, 0, 0, 0, 0, 0}
		weapon[0] = 0
		setBackground('darkJungle.JPG')
		if(team[0] == 1) then
		   --createTextfield("Sergeant " .. string.format("%s", print(teamName[0])) .. " asks for you to bring 3 sets of weapons with you to increase mobility. Thus decreasing the chance of the agile enemy capturing you.")
		   createTextfield("Sergeant Dwight Power asks for you to bring 3\nsets of weapons with you to increase mobility. Thus decreasing the chance of the\nagile enemy capturing you.")
		end
		if(team[1] == 1) then
		   createTextfield("Sergeant Jean O. Cider asks for you to bring 3\nsets of weapons with you to increase mobility. Thus decreasing the chance of the\nagile enemy capturing you.")
		end
		if(team[2] == 1) then
		   createTextfield("Sergeant F. Nick Glensing asks for you to bring 3\nsets of weapons with you to increase mobility. Thus decreasing the chance of the\nagile enemy capturing you.")
		end
		if(team[3] == 1) then
		   createTextfield("Sergeant K. Lanceman asks for you to bring 3\nsets of weapons with you to increase mobility. Thus decreasing the chance of the agile\nenemy capturing you.")
		end
		createButton("exit", " ")
		createButton("weapon05", "Remote Controlled Claymores")
		createButton("weapon04", "RPG")
		createButton("weapon03", "Grenade Belt")
		createButton("weapon02", "Hunting Rifle with Scope")
		createButton("weapon01", "Assault Rifle")
		createButton("weapon00", "Dual Pistols")
	end
	if(aName == "weapon00") then
	    weapon[0] = 1
		aName = "secondQuestion"
    end
	if(aName == "weapon01") then
	    weapon[1] = 1
		aName = "secondQuestion"
    end
	if(aName == "weapon02") then
	    weapon[2] = 1
		aName = "secondQuestion"
    end
	if(aName == "weapon03") then
	    weapon[3] = 1
		aName = "secondQuestion"
    end
	if(aName == "weapon04") then
	    weapon[4] = 1
		aName = "secondQuestion"
    end
	if(aName == "weapon05") then
	    weapon[5] = 1
		aName = "secondQuestion"
    end
	if(aName == "secondQuestion") then
	    CLS()
		setBackground('darkJungle.JPG')
        createTextfield("Pick 2 more sets of weapons.")
		createButton("exit", " ")
		createButton("weaponBegin", "Back")
		if(weapon[5] == 0) then
		createButton("weapon11", "Remote Controlled Claymores")
		end
		if(weapon[4] == 0) then
		createButton("weapon10", "RPG")
		end
		if(weapon[3] == 0) then
		createButton("weapon09", "Grenade Belt")
		end
		if(weapon[2] == 0) then
		createButton("weapon08", "Hunting Rifle with Scope")
		end
		if(weapon[1] == 0) then
		createButton("weapon07", "Assault Rifle")
		end
		if(weapon[0] == 0) then
		createButton("weapon06", "Dual Pistols")
		end
    end
	if(aName == "weapon06") then
	    weapon[0] = 1
		aName = "thirdQuestion"
    end
	if(aName == "weapon07") then
	    weapon[1] = 1
		aName = "thirdQuestion"
    end
	if(aName == "weapon08") then
	    weapon[2] = 1
		aName = "thirdQuestion"
    end
	if(aName == "weapon09") then
	    weapon[3] = 1
		aName = "thirdQuestion"
    end
	if(aName == "weapon10") then
	    weapon[4] = 1
		aName = "thirdQuestion"
    end
	if(aName == "weapon11") then
	    weapon[5] = 1
		aName = "thirdQuestion"
    end
	if(aName == "thirdQuestion") then
	    CLS()
		setBackground('darkJungle.JPG')
        createTextfield("One more set of weapons, if you please.")
		createButton("exit", " ")
		createButton("weaponBegin", "Redo my choices.")
		if(weapon[5] == 0) then
		createButton("weapon17", "Remote Controlled Claymores")
		end
		if(weapon[4] == 0) then
		createButton("weapon16", "RPG")
		end
		if(weapon[3] == 0) then
		createButton("weapon15", "Grenade Belt")
		end
		if(weapon[2] == 0) then
		createButton("weapon14", "Hunting Rifle with Scope")
		end
		if(weapon[1] == 0) then
		createButton("weapon13", "Assault Rifle")
		end
		if(weapon[0] == 0) then
		createButton("weapon12", "Dual Pistols")
		end
    end
	if(aName == "weapon12") then
	    weapon[0] = 1
		aName = "sure"
    end
	if(aName == "weapon13") then
	    weapon[1] = 1
		aName = "sure"
    end
	if(aName == "weapon14") then
	    weapon[2] = 1
		aName = "sure"
    end
	if(aName == "weapon15") then
	    weapon[3] = 1
		aName = "sure"
    end
	if(aName == "weapon16") then
	    weapon[4] = 1
		aName = "sure"
    end
	if(aName == "weapon17") then
	    weapon[5] = 1
		aName = "sure"
    end
	if(aName == "sure") then
	    CLS()
		
		for i=0, 5 do
		print(weapon[i])
		end
		
		setBackground('darkJungle.JPG')
		--if(weapon == {1, 1, 1, 0, 0, 0}) then
		if(weapon[0] == 1 and weapon[1] == 1 and weapon[2] == 1 and weapon[3] == 0 and weapon[4] == 0 and weapon[5] == 0) then
        createTextfield("You chose the Dual Pistols, the Assault Rifle and\nthe Hunting Rifle with Scope. Confirmation to bring these?")
		end
		if(weapon[0] == 1 and weapon[1] == 1 and weapon[2] == 0 and weapon[3] == 1 and weapon[4] == 0 and weapon[5] == 0) then
        createTextfield("You chose the Dual Pistols, the Assault Rifle and\nthe Grenade Belt. Confirmation to bring these?")
		end
		if(weapon[0] == 1 and weapon[1] == 1 and weapon[2] == 0 and weapon[3] == 0 and weapon[4] == 1 and weapon[5] == 0) then
        createTextfield("You chose the Dual Pistols, the Assault Rifle and\nthe RPG. Confirmation to bring these?")
		end
		if(weapon[0] == 1 and weapon[1] == 1 and weapon[2] == 0 and weapon[3] == 0 and weapon[4] == 0 and weapon[5] == 1) then
        createTextfield("You chose the Dual Pistols, the Assault Rifle and\nRemote Controlled Claymores. Confirmation to bring these?")
		end
		if(weapon[0] == 1 and weapon[1] == 0 and weapon[2] == 1 and weapon[3] == 1 and weapon[4] == 0 and weapon[5] == 0) then
        createTextfield("You chose the Dual Pistols, the Hunting Rifle with\nScope and the Grenade Belt. Confirmation to bring these?")
		end
		if(weapon[0] == 1 and weapon[1] == 0 and weapon[2] == 1 and weapon[3] == 0 and weapon[4] == 1 and weapon[5] == 0) then
        createTextfield("You chose the Dual Pistols, the Hunting Rifle with\nScope and the RPG. Confirmation to bring these?")
		end
		if(weapon[0] == 1 and weapon[1] == 0 and weapon[2] == 1 and weapon[3] == 0 and weapon[4] == 0 and weapon[5] == 1) then
        createTextfield("You chose the Dual Pistols, the Hunting Rifle with\nScope and Remote Controlled Claymores. Confirmation to bring these?")
		end
		if(weapon[0] == 1 and weapon[1] == 0 and weapon[2] == 0 and weapon[3] == 1 and weapon[4] == 1 and weapon[5] == 0) then
        createTextfield("You chose the Dual Pistols, the Grenade Belt and\nthe RPG. Confirmation to bring these?")
		end
		if(weapon[0] == 1 and weapon[1] == 0 and weapon[2] == 0 and weapon[3] == 1 and weapon[4] == 0 and weapon[5] == 1) then
        createTextfield("You chose the Dual Pistols, the Grenade Belt and\nRemote Controlled Claymores. Confirmation to bring these?")
		end
		if(weapon[0] == 1 and weapon[1] == 0 and weapon[2] == 0 and weapon[3] == 0 and weapon[4] == 1 and weapon[5] == 1) then
        createTextfield("You chose the Dual Pistols, the RPG and Remote\nControlled Claymores. Confirmation to bring these?")
		end
		if(weapon[0] == 0 and weapon[1] == 1 and weapon[2] == 1 and weapon[3] == 1 and weapon[4] == 0 and weapon[5] == 0) then
        createTextfield("You chose the Assault Rifle, the Hunting Rifle with\nScope and the Grenade Belt. Confirmation to bring these?")
		end
		if(weapon[0] == 0 and weapon[1] == 1 and weapon[2] == 1 and weapon[3] == 0 and weapon[4] == 1 and weapon[5] == 0) then
        createTextfield("You chose the Assault Rifle, the Hunting Rifle with\nScope and the RPG. Confirmation to bring these?")
		end
		if(weapon[0] == 0 and weapon[1] == 1 and weapon[2] == 1 and weapon[3] == 0 and weapon[4] == 0 and weapon[5] == 1) then
        createTextfield("You chose the Assault Rifle, the Hunting Rifle with\nScope and Remote Controlled Claymores. Confirmation to bring these?")
		end
		if(weapon[0] == 0 and weapon[1] == 1 and weapon[2] == 0 and weapon[3] == 1 and weapon[4] == 1 and weapon[5] == 0) then
        createTextfield("You chose the Assault Rifle, the Grenade Belt and\nthe RPG. Confirmation to bring these?")
		end
		if(weapon[0] == 0 and weapon[1] == 1 and weapon[2] == 0 and weapon[3] == 1 and weapon[4] == 0 and weapon[5] == 1) then
        createTextfield("You chose the Assault Rifle, the Grenade Belt and\nRemote Controlled Claymores. Confirmation to bring these?")
		end
		if(weapon[0] == 0 and weapon[1] == 0 and weapon[2] == 1 and weapon[3] == 1 and weapon[4] == 1 and weapon[5] == 0) then
        createTextfield("You chose the Hunting Rifle with Scope, the Grenade\nBelt and the RPG. Confirmation to bring these?")
		end
		if(weapon[0] == 0 and weapon[1] == 0 and weapon[2] == 1 and weapon[3] == 1 and weapon[4] == 0 and weapon[5] == 1) then
        createTextfield("You chose the Hunting Rifle with Scope, the Grenade\nBelt and Remote Controlled Claymores. Confirmation to bring these?")
		end
		if(weapon[0] == 0 and weapon[1] == 0 and weapon[2] == 1 and weapon[3] == 0 and weapon[4] == 1 and weapon[5] == 1) then
        createTextfield("You chose the Hunting Rifle with Scope, the RPG and\nRemote Controlled Claymores. Confirmation to bring these?")
		end
		if(weapon[0] == 0 and weapon[1] == 0 and weapon[2] == 0 and weapon[3] == 1 and weapon[4] == 1 and weapon[5] == 1) then
        createTextfield("You chose the Grenade Belt, the RPG and Remote\nControlled Claymores. Confirmation to bring these?")
		end
		createButton("exit", " ")
		createButton("travellers", "Affirmative, sir.")
		createButton("weaponBegin", "Nope.")
    end
	if(aName == "travellers") then
	    CLS()
		setBackground('darkJungle.JPG')
        createTextfield("\"It sure as hell is quiet around here. Hey Private,\nwhat do you think?\"")
		createButton("exit", " ")
		createButton("ambushSound", "... (Stay silent)")
		createButton("ambushSound", "Sir, I think this would not be the...")
		createButton("ambushSound", "Maybe a bit too quiet.")
    end
	if(aName == "ambushSound") then
	    CLS()
		playSound("pageFlip.wav")
		setBackground('darkJungle.JPG')
        createTextfield("You hear a sound... It is coming from the trees.")
		createButton("exit", " ")
		createButton("walk", "Continue walking")
		createButton("turn", "Turn around")
    end
	if(aName == "turn") then
	    CLS()
		setBackground('darkJungle.JPG')
        createTextfield("It appears your team has encountered the enemies. As\nit turns out, you'll be facing Invisible Cyborg Guerillas. As silent as the night, as\ndeadly as a chemical agent.")
		createButton("exit", " ")
		if(team[3] == 1) then
		    createButton("shooting", "Sergeant Lanceman, watch out, sir!")
		end
		if(team[2] == 1) then
		    createButton("shooting", "Sergeant Glensing, watch out, sir!")
		end
		if(team[1] == 1) then
		    createButton("shooting", "Sergeant Cider, watch out, sir!")
		end
		if(team[0] == 1) then
		    createButton("shooting", "Sergeant Power, watch out, sir!")
		end
    end
	if(aName == "walk") then
	    CLS()
		playSound("gunShots01.wav")
		setBackground('darkJungle.JPG')
        createTextfield("You and your colleagues have been killed by the\nInvisible Cyborg Guerillas.")
		createButton("exit", " ")
		createButton("start", "Well, crap.")
    end
	if(aName == "shooting") then
	    CLS()
		playSound("gunShots01.wav")
		setBackground('darkJungle.JPG')
		createTextfield("The sound of shooting ensues. The direction of which\nyou do not know yet.")
		createButton("exit", " ")
		createButton("battle00", "Perhaps my teammates can be of assistance.")
    end
	if(aName == "battle00") then
	    CLS()
		setBackground('darkJungle.JPG')
		if(team[3] == 1) then
		    playSound("gunShots01.wav")
		    createTextfield("Corporal K. Marks Karlson was about to be shot at by\nthe enemies, but Sergeant K. Lanceman managed to take the hit. He's been killed\ninstantly by the rain of bullets.")
		end
		if(team[2] == 1) then
		    createTextfield("Sergeant F. Nick Glensing did some training with the\nSpecial Forces. His eyes are slowly accustomed to the cyborgs' cloaking\ntechniques.")
		end
		if(team[1] == 1) then
		    playSound("gunShots01.wav")
		    createTextfield("Sergeant Jean O. Cider brought a Minigun on this\nmission. She starts to shoot the trees with little luck of hitting anything.")
		end
		if(team[0] == 1) then
		    createTextfield("Sergeant Dwight Power brought special binoculars\nwith infra-red support. He knew it might come in handy. He knows where the enemy is now.")
		end
		createButton("exit", " ")
		createButton("battle01", "Attack.")
    end
	if(aName == "battle01") then
	    CLS()
		setBackground('darkJungle.JPG')
		if(team[3] == 1) then
		    playSound("gunShots01.wav")
		    createTextfield("Corporal Karlson decides to shoot with his Assault\nRifle at the trees without any luck. He is soon to be killed, if not acted quickly\nupon.")
		end
		if(team[2] == 1) then
		    createTextfield("Sergeant Glensing brought a Hunting Rifle with\nScope and shoots a Cyborg Guerilla in an instant. It was a clean headshot.")
		end
		if(team[1] == 1) then
		    createTextfield("Sergeant Cider is soon to be ambushed from behind.\nAct quickly before they can get to her.")
		end
		if(team[0] == 1) then
		    playSound("gunShots01.wav")
		    createTextfield("Sergeant Power decides to shoot with his Assault\nRifle. He managed to hit a few Invisible Cyborg Guerillas, but they don't go down\nthat easily.")
		end
		createButton("exit", " ")
		if(weapon[5] == 1) then
		createButton("battle02", "Bring down those trees.")
		end
		if(weapon[4] == 1) then
		createButton("endScreen", "Use 1 of your rockets to blast 'em out of the tree.")
		end
		if(weapon[3] == 1) then
		createButton("endScreen", "Throw some explosives.")
		end
		if(weapon[2] == 1) then
		createButton("battle03", "Take the time to aim, before you shoot anything.")
		end
		if(weapon[1] == 1) then
		createButton("endScreen", "Spray 'em with bullets.")
		end
		if(weapon[0] == 1) then
		createButton("endScreen", "Use the Pistols.")
		end
    end
	if(aName == "battle02") then
	    CLS()
		playSound("boom01.wav")
		setBackground('heat.JPG')
		createTextfield("You bring down the trees by sticking Remote\nControlled Claymores on the trunks and by detonating them. The Invisible Cyborg Guerillas\ndon't have the high ground any more.")
		createButton("exit", " ")
		createButton("damage00", "That's a lotta' damage!")
		createButton("battle04", "Oops!")
		createButton("battle04", "Take that, you prick!")
    end
	if(aName == "battle03") then
	    CLS()
		setBackground('darkJungle.JPG')
		if(team[3] == 1) then
		    playSound("gunShots01.wav")
		    createTextfield("You missed your shot. Unfortunately Corporal K.\nMarks Karlson did not survive his encounter with the Invisible Cyborg Guerillas.\nYou are on your own now.")
		end
		if(team[2] == 1) then
		    createTextfield("You shot the Cyborg Guerilla who was ambushing\nSergeant F. Nick Glensing from behind. But a Cyborg Guerilla tries to stab you now from\nbehind.")
		end
		if(team[1] == 1) then
		    createTextfield("You shot the Cyborg Guerilla who was ambushing\nSergeant Jean O. Cider from behind. But there were more Cyborg Guerillas ambushing the\nSergeant.")
		end
		if(team[0] == 1) then
		    createTextfield("You killed 1 Cyborg Guerilla as soon as he fell out\nof the tree. Sergeant Dwight Power is doing a good job keeping them on the ground.")
		end
		createButton("exit", " ")
		if(team[3] == 1) then
		    createButton("endScreen", "Lord, have mercy on this soul of mine.")
		    createButton("endScreen", "It seems like a good day to die!")
			createButton("endScreen", "I'll never succumb to Scion!")
		end
		if(team[2] == 1) then
		    if(weapon[0] == 1) then
		    createButton("endScreen", "Use these short-range firearms.")
		    else
			createButton("endScreen", "Oh no.")
			end
		end
		if(team[1] == 1) then
		    createButton("endScreen", "Sir! Watch out!")
			if(weapon[4] == 1) then
		    createButton("endScreen", "Use 1 of your rockets to defend the Sergeant.")
		    end
		    if(weapon[3] == 1) then
		    createButton("endScreen", "Throw a Grenade.")
		    end
			if(weapon[1] == 1) then
		    createButton("endScreen", "Spray 'em with bullets.")
			else
			    if(weapon[0] == 1) then
		        createButton("endScreen", "Spray 'em with bullets.")
				end
		    end
		end
		if(team[0] == 1) then
		    createButton("endScreen", "Yeah, you like that? You son of a...")
			createButton("endScreen", "Sir, keep shooting! It's working!")
		end
    end
	if(aName == "damage00") then
	    CLS()
		createTextfield("\"Wait, did you really use that line?\"")
		createButton("exit", " ")
		createButton("battle04", "Yeah.")
	end
	if(aName == "battle04") then
	    CLS()
		setBackground('darkJungle.JPG')
		if(team[3] == 1) then
		    createTextfield("Now the Invisible Cyborg Guerillas are ambushing\nCorporal K. Marks Karlson on the ground. Cover your remaining teammember.")
		end
		if(team[2] == 1) then
		    createTextfield("Now a Cyborg Guerilla tries to ambush Sergeant F.\nNick Glensing. Cover the Sergeant.")
		end
		if(team[1] == 1) then
		    playSound("gunShots01.wav")
		    createTextfield("Sergeant Jean O. Cider was overpowered by the deadly\nenemy forces and their bullets. It's now up to you and Corporal Han E. Groids.")
		end
		if(team[0] == 1) then
		    createTextfield("The blast's heat makes it hard for Sergeant Dwight\nPower to see the Invisible Cyborg Guerillas with infra-red vision. What would you do\nnow?")
		end
		createButton("exit", " ")
		if(team[3] == 1) then
		    if(weapon[4] == 1) then
		    createButton("endScreen", "Use 1 of your rockets with the RPG.")
		    end
		    if(weapon[3] == 1) then
		    createButton("endScreen", "Use the Grenades.")
		    end
		    if(weapon[2] == 1) then
		    createButton("endScreen", "Take the time to aim, before you shoot anything.")
		    end
		    if(weapon[1] == 1) then
		    createButton("endScreen", "Spray 'em with bullets.")
		    end
		    if(weapon[0] == 1) then
		    createButton("endScreen", "Dual wield the Handguns to cover the Corporal.")
		    end
		end
		if(team[2] == 1) then
		    if(weapon[4] == 1) then
		    createButton("endScreen", "Use 1 of your rockets with the RPG.")
		    end
		    if(weapon[3] == 1) then
		    createButton("endScreen", "Use the Grenades.")
		    end
		    if(weapon[2] == 1) then
		    createButton("endScreen", "Take the time to aim, before you shoot anything.")
		    end
		    if(weapon[1] == 1) then
		    createButton("endScreen", "Spray 'em with bullets.")
		    end
		    if(weapon[0] == 1) then
		    createButton("endScreen", "Dual wield the Handguns to cover the Sergeant.")
		    end
		end
		if(team[1] == 1) then
		    createButton("endScreen", "Corporal cover me!")
		    createButton("endScreen", "Cover the Corporal.")
		end
		if(team[0] == 1) then
		    createButton("choke", "Sorry for your aim, sir.")
		end
    end
	if(aName == "choke") then
	    CLS()
		setBackground('darkJungle.JPG')
		createTextfield("\"You can choke on it, Private! What's more important\nis getting out alive!\"")
		createButton("exit", " ")
		if(weapon[4] == 1) then
		createButton("endScreen", "Send 'em flying.")
		end
		if(weapon[3] == 1) then
		createButton("endScreen", "They're going out with a bang.")
		end
		if(weapon[2] == 1) then
		createButton("endScreen", "Take the time to aim, before you shoot anything.")
		end
		if(weapon[1] == 1) then
		createButton("endScreen", "Spray 'em with bullets.")
		end
		if(weapon[0] == 1) then
		createButton("endScreen", "Grab these Glocks and party.")
		end
	end
	if(aName == "endScreen") then
	    CLS()
		playSound("gunShots01.wav")
		setBackground('burningForrest.JPG')
		createTextfield("Unfortunately, I did not have enough time to go\nfurther this route.")
		createButton("exit", " ")
		createButton("exit", "Whatever, cheap bastard.")
		createButton("start", "Play a different route, then! Jeez.")
    end
	if(aName == "exit") then
		exitGame();
	end	
end