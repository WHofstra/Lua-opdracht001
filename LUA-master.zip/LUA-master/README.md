# LUA point and click adventure
Op deze repository staan alleen de dingen die door mij zijn aangepast.
De Script.lua file is geheel vervangen door een script die ik zelf heb geschreven.
De TrueType-lettertypebestand bevat nu een ander font genaamd 'Veteran Typewriter', deze
  is gratis te downloaden voor persoonlijk en comerciëel gebruik:
  https://www.1001fonts.com/veteran-typewriter-font.html
De geluiden die voor deze opdracht gebruikt zijn zitten in de 'Sounds' folder en komen van deze bron:
  https://www.youtube.com/watch?v=BBI6-Wyjgwk
De achtergronden die ik heb toegevoegd zijn te vinden in de 'Textures' folder.
De muziek die voor deze opdracht gebruikt werd, kon niet overgebracht worden aan de repository.
Dat muziek-file is zelfs in .wav format 60.4 MB in geheugen. De repository kan maximaal 25 MB hebben aan
  geïmporteerde bestanden. Muziek dat gebruikt werd voor deze opdracht is hier te vinden:
  https://www.youtube.com/watch?v=F_hFEXG7dzg
  